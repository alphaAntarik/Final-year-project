package com.example.trying_api_with_sending_data

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
